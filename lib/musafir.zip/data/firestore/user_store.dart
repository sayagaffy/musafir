import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:musafir/base/dialog_helper.dart';
import 'package:musafir/base/show_custom_snackbar.dart';
import 'package:musafir/controllers/explore_controller.dart';
import 'package:musafir/routes/routes_helper.dart';
import 'package:musafir/shared/theme.dart';

class UserStore {
  final FirebaseAuth auth = FirebaseAuth.instance;
  // collection reference
  final CollectionReference dbUsers =
      FirebaseFirestore.instance.collection('users');
  final CollectionReference dbReviews =
      FirebaseFirestore.instance.collection('reviews');
  final CollectionReference dbBookmark =
      FirebaseFirestore.instance.collection('bookmark');
  final CollectionReference dbExplore =
      FirebaseFirestore.instance.collection('explore');
  final expC = Get.find<ExploreController>();

  Future createUser({
    String? username,
    String? bio,
    String? photoURL,
    String? firstName,
    String? lastName,
    String? phone,
    String? provider,
    String? address,
    String? latlang,
  }) async {
    return await dbUsers.doc(auth.currentUser!.email).set({
      'username': username,
      'bio': bio,
      'profilePhoto': photoURL,
      'firstName': firstName,
      'lastName': lastName,
      'phone': phone,
      'provider': provider,
      'address': address,
      'lat': latlang,
      'lng': latlang,
      'creatAt': DateTime.now(),
    });
  }

  Future getUserDetail() async {
    return await dbUsers
        .doc(auth.currentUser!.email)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        Map<String, dynamic> data =
            documentSnapshot.data() as Map<String, dynamic>;
        return data;
      } else {
        return ('Document does not exist on the database');
      }
    });
  }

  Future updateUserData(dynamic data) async {
    try {
      final querySnapshot =
          await dbUsers.doc(auth.currentUser!.email).update(data);
      return querySnapshot;
    } catch (error) {
      showCustomSnackBar(error.toString());
      throw 'failed';
    }
  }

  Future updateUserPlace(dynamic data) async {
    await dbUsers.doc(auth.currentUser!.email).update(data).then((value) {
      DialogHelper.hideLoading();
      DialogHelper.showSnackBar(
        'Berhasil  update  place',
        title: 'Successfuly',
        backgroundColor: kSuccessMain,
      );
    }).catchError((error) {
      DialogHelper.showErroDialog(description: error.toString());
    });
  }

  Future postingReview(
    String placeid,
    String latlang,
    String authorName,
    String authorEmail,
    String authorPhotoUrl,
    String rating,
    String review,
    String page,
    String from,
  ) async {
    DialogHelper.showLoading('Posting Review..');

    return await dbReviews.doc().set({
      'place_id': placeid,
      'latlang': latlang,
      'author_name': authorName,
      'author_email': authorEmail,
      'profile_photo_url': authorPhotoUrl,
      'rating': rating,
      'text': review,
      'creatAt': DateTime.now(),
    }).then((value) {
      DialogHelper.hideLoading();

      DialogHelper.showSnackBar(
        'Berhasil posting reviews',
        title: 'Successfuly',
        backgroundColor: kSuccessMain,
      );

      Timer(const Duration(seconds: 5), () {
        Get.toNamed(RouteHelper.getHomeDetailPage(placeid, page, from, 'NONE'));
      });
    }).catchError((error) {
      DialogHelper.showErroDialog(description: error.toString());
    });
  }

  Future checkUserReview(String placeId) async {
    dynamic review;
    await dbReviews
        .where("place_id", isEqualTo: placeId)
        .where('author_email', isEqualTo: auth.currentUser!.email)
        .get()
        .then(
          (QuerySnapshot docs) => {
            for (var element in docs.docs) {review = element.data()},
          },
        );
    return review;
  }

  Future bookmarkPlace(String placeid, String latlang, String page, String from,
      String address, String halalStatus, String type, String photoUrl) async {
    DialogHelper.showLoading('Bookmark Place..');
    final collection = dbBookmark.doc(auth.currentUser!.email);
    final docSnap = await collection.get();
    Map<String, dynamic> payload = {
      "place_id": placeid,
      "latlang": latlang,
      'place_name': page,
      'address': address,
      'halal': halalStatus,
      'type': type,
      'photo': photoUrl,
      'creatAt': DateTime.now(),
    };

    return await collection
        .get()
        .then((DocumentSnapshot documentSnapshot) async {
      if (documentSnapshot.exists) {
        List cart = docSnap.get('place');
        List item = cart
            .where((element) => element['place_id'].contains(placeid))
            .toList();
        if (item.isEmpty) {
          ///[Update bookmark]
          dbBookmark.doc(auth.currentUser!.email).update({
            'place': FieldValue.arrayUnion([payload]),
          }).then((value) {
            DialogHelper.hideLoading();
            DialogHelper.showSnackBar(
              'Berhasil  bookmark tempat',
              title: 'Successfuly',
              backgroundColor: kSuccessMain,
            );
          }).catchError((error) {
            DialogHelper.showErroDialog(description: error.toString());
          });
        } else {
          ///[Remove bookmark]
          collection
              .update({'place': FieldValue.arrayRemove(item)}).then((value) {
            DialogHelper.hideLoading();
            DialogHelper.showSnackBar(
              'Berhasil Hapus bookmark tempat',
              title: 'Successfuly',
              backgroundColor: kSuccessMain,
            );
          }).catchError((error) {
            DialogHelper.showErroDialog(description: error.toString());
          });
        }
      } else {
        ///[Create if colection not ready yet]
        dbBookmark.doc(auth.currentUser!.email).set({
          'place': FieldValue.arrayUnion([payload]),
        }).then((value) {
          DialogHelper.hideLoading();
          DialogHelper.showSnackBar(
            'Berhasil bookmark tempat',
            title: 'Successfuly',
            backgroundColor: kSuccessMain,
          );
        }).catchError((error) {
          DialogHelper.showErroDialog(description: error.toString());
        });
      }
    });
  }

  Future checkBookmark(String placeid) async {
    final collection = dbBookmark.doc(auth.currentUser!.email);
    final docSnap = await collection.get();
    return await collection
        .get()
        .then((DocumentSnapshot documentSnapshot) async {
      if (documentSnapshot.exists) {
        List cart = docSnap.get('place');
        List item = cart
            .where((element) => element['place_id'].contains(placeid))
            .toList();
        if (item.isEmpty) {
          return false;
        } else {
          return true;
        }
      } else {
        return false;
      }
    });
  }

  Future bookmarkList() async {
    return await dbBookmark
        .doc(auth.currentUser!.email)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        Map<String, dynamic> data =
            documentSnapshot.data() as Map<String, dynamic>;

        return data;
      } else {
        return null;
      }
    });
  }

  Future explorePlan(
      String placeId,
      String address,
      String startTime,
      String endTime,
      String namePlan,
      List resto,
      List mosque,
      double lat,
      double lng) async {
    Map<String, dynamic> payload = {
      "place_id": placeId,
      'place_name': address,
      'start_time': startTime,
      'end_time': endTime,
      'name_plan': namePlan,
      'resto': resto,
      'mosque': mosque,
      'lat': lat,
      'lng': lng,
      'creatAt': DateTime.now(),
      'email': auth.currentUser!.email,
    };

    dbExplore.doc().set(payload).then((value) {
      DialogHelper.hideLoading();
      DialogHelper.showSnackBar(
        "Berhasil Membuat Rencana Perjalanan",
        title: "Berhasil",
        backgroundColor: kSuccessMain,
      );

      expC.clearAll();
      Get.offNamed(RouteHelper.getInitial());
    }).catchError((error) {
      DialogHelper.hideLoading();
      DialogHelper.showErroDialog(description: error.toString());
    });
  }

  Future explorePlanUpdates(
      String id,
      String placeId,
      String address,
      String startTime,
      String endTime,
      String namePlan,
      List resto,
      List mosque,
      double lat,
      double lng) async {
    Map<String, dynamic> payload = {
      "place_id": placeId,
      'place_name': address,
      'start_time': startTime,
      'end_time': endTime,
      'name_plan': namePlan,
      'resto': resto,
      'mosque': mosque,
      'lat': lat,
      'lng': lng,
      'creatAt': DateTime.now(),
      'email': auth.currentUser!.email,
    };

    dbExplore.doc(id).update(payload).then((value) {
      DialogHelper.hideLoading();
      DialogHelper.showSnackBar(
        "Berhasil Update Rencana Perjalanan",
        title: "Berhasil",
        backgroundColor: kSuccessMain,
      );
      Get.offNamed(RouteHelper.getInitial());
    }).catchError((error) {
      DialogHelper.hideLoading();
      DialogHelper.showErroDialog(description: error.toString());
    });
  }

  Future exploreDelete(String id) async {
    dbExplore.doc(id).delete().then((value) {
      DialogHelper.hideLoading();
      DialogHelper.showSnackBar(
        "Berhasil Menghapus Rencana Perjalanan",
        title: "Berhasil",
        backgroundColor: kSuccessMain,
      );
    }).catchError((error) {
      DialogHelper.hideLoading();
      DialogHelper.showErroDialog(description: error.toString());
    });
  }

  Future exploreList() async {
    dynamic explorePlan;
    await dbExplore
        .where("email", isEqualTo: auth.currentUser!.email)
        .get()
        .then((QuerySnapshot querySnapshot) => {explorePlan = querySnapshot},
            onError: (e) => debugPrint("Error completing: $e"));
    return explorePlan;
  }
}
