import 'package:flutter/material.dart';
import 'package:musafir/shared/theme.dart';

class FavoriteCard extends StatelessWidget {
  final String name;
  final String city;
  final String imgUrl;

  final bool isMasjid;
  final EdgeInsets margin;

  final double km;

  const FavoriteCard({
    super.key,
    required this.name,
    required this.city,
    this.isMasjid = false,
    this.margin = const EdgeInsets.only(right: 15),
    this.imgUrl = 'none',
    this.km = 0.4,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 178,
      height: 175,
      margin: margin,
      decoration: BoxDecoration(
        color: kWhiteColor,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.3),
            spreadRadius: 1,
            blurRadius: 2,
            offset: const Offset(1.5, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            height: 90,
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
              image: imgUrl == 'none'
                  ? const DecorationImage(
                      fit: BoxFit.cover,
                      image: AssetImage('assets/image_destination1.png'),
                    )
                  : DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage(imgUrl),
                    ),
            ),
          ),
          Container(
            padding: const EdgeInsets.only(
              left: 10,
              right: 10,
              top: 5,
              bottom: 10,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: blackTextStyle.copyWith(
                    fontSize: 14,
                    fontWeight: extraBold,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Container(
                  margin: const EdgeInsets.only(top: 1),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        city,
                        style: blackTextStyle.copyWith(
                          fontSize: 12,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: !isMasjid ? 2 : 4,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      // Row(
                      //   children: [
                      //     Icon(
                      //       Icons.location_on_rounded,
                      //       size: 16,
                      //       color: kRedMain,
                      //     ),
                      //     Text(
                      //       '$km km',
                      //       style: blackTextStyle.copyWith(fontSize: 12),
                      //     ),
                      //   ],
                      // ),
                      const SizedBox(
                        height: 5,
                      ),
                      SizedBox(
                        child: !isMasjid
                            ? Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        width: 16,
                                        height: 16,
                                        margin: const EdgeInsets.only(
                                          right: 3,
                                        ),
                                        decoration: const BoxDecoration(
                                          image: DecorationImage(
                                            image: AssetImage(
                                                'assets/icon_halal.png'),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        'Halal Certified',
                                        style: blackTextStyle.copyWith(
                                          fontSize: 12,
                                          fontWeight: bold,
                                          color: kGreenHover,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(
                                    height: 1,
                                  ),
                                ],
                              )
                            : const SizedBox(
                                height: 1,
                              ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
